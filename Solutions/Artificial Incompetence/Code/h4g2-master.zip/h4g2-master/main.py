import os
import logging
from logging.handlers import RotatingFileHandler

import torch
import numpy as np

from arg_utils import parse_args
from trainer import Trainer
from video_classifier import VideoClassifier
import commont_util

def supress_log(lib_name):
    logging.getLogger(lib_name).setLevel(logging.INFO)

def configure_logging(module, verbose):
    handlers = [
        RotatingFileHandler(
            "logs/{}.log".format(module), maxBytes=1048576*5, backupCount=7),
        logging.StreamHandler()
    ]
    log_format = "[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] %(message)s"
    if verbose:
        logging.basicConfig(level=logging.DEBUG,
                            handlers=handlers, format=log_format)
    else:
        logging.basicConfig(level=logging.INFO,
                            handlers=handlers, format=log_format)


if __name__ == '__main__':

    args = parse_args()

    if args.module is None:
        raise ValueError("Provide a module to run! Use the (--help) flag")

    configure_logging(args.module, args.verbose)

    for lib_name in {"PIL", "matplotlib"}:
        supress_log(lib_name)

    log = logging.getLogger("root")

    log.info("Arguments: {}".format(args))

    # set seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    if hasattr(args, "device") and args.device != "cpu":
        torch.cuda.manual_seed_all(args.seed)

    if args.module == "train":
        trainer = Trainer(args)
        if not args.test:
            trainer.train(args.num_epochs)
        else:
            trainer.load()
            trainer.test()
    elif args.module == "clf":
        clf = VideoClassifier(args)
        clf.run(args.input, args.output, args.skip_frames, args.make_plots)
    elif args.module == "run-clf":
        clf = VideoClassifier(args)
        commont_util.mkdir(args.output)

        for video in os.listdir(args.input):
            video_id = video.split(".")[0]
            video_id = video_id + "_det.mp4"

            dest_path = os.path.join(args.output, video_id)

            if os.path.exists(dest_path):
                log.info("File already exists: {}".format(dest_path))
                continue
            clf.run(os.path.join(args.input, video), 
                    dest_path,
                    args.skip_frames)
            
    elif args.module == "test-clf":
        clf = VideoClassifier(args)

        root = "./UNICRI Challenge Dataset"
        classes = ["Deepfakes", "Face2Face", "FaceSwap", "Original"]

        results_folder = "our_results"
        commont_util.mkdir(results_folder)
        commont_util.mkdir(os.path.join(results_folder, args.id))
        for cl in classes:
            for file_id in os.listdir(os.path.join(root, cl)):
                if not file_id.startswith(args.id):
                    continue
                
                clf.run(os.path.join(root, cl, file_id), 
                        os.path.join(results_folder, args.id, f"{cl}.mp4"),
                        args.skip_frames)