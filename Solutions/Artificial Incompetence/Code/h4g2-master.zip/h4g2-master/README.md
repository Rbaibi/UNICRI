# h4g2


## Installation Instructions:


1. Install packages from: https://github.com/ageitgey/face_recognition/blob/master/Dockerfile#L6-L34
2. 

```
# install face_recognition lib
sudo apt install -y --fix-missing     build-essential     cmake     gfortran     git     wget     curl     graphicsmagick     libgraphicsmagick1-dev     libatlas-dev     libavcodec-dev     libavformat-dev     libgtk2.0-dev     libjpeg-dev     liblapack-dev     libswscale-dev     pkg-config     python3-dev    software-properties-common     zip
git clone https://github.com/davisking/dlib.git
cd dlib
mkdir build; cd build; cmake ..; cmake --build .
cd ..
python3 setup.py install
cd ..



# install pytorch - according to the xception model
pip install torch==1.0.1 -f https://download.pytorch.org/whl/cpu/stable # This is CPU only, so pick appropriate one
pip install torchvision==0.2.1
pip install pretrainedmodels==0.7.4

# other libs
pip install imageio
pip install imageio-ffmpeg
pip install jupyter
pip install matplotlib

# download the model
wget http://kaldir.vc.in.tum.de/FaceForensics/models/faceforensics++_models.zip
unzip "faceforensics++_models.zip" # change folder name to "ffmodels"

# we don't explicitly use the FaceForensics code,
# but since the authors of FF don't save the weights
# (they save the entire class), we have to do this 
# hacky thing - the code's already committed

# packages for the back end
pip install django sqlparse djangorestframework django-cors-headers


```

## How to run 

Note: All files have a `--help` flag. 

```
usage: main.py [-h] [--verbose] [--seed SEED] {train,clf,run-clf,test-clf} ...

positional arguments:
  {train,clf,run-clf,test-clf}
                        module to run
    train               train a model
    clf                 run on video
    run-clf             run on video
    test-clf            run on video

optional arguments:
  -h, --help            show this help message and exit
  --verbose             set to true for verbose output
  --seed SEED           random seed
```

Use `python main.py <module> --help` for specifc modules:
Ex Training: `python main.py train --help`
```
usage: main.py train [-h] --model-id MODEL_ID [--num-workers NUM_WORKERS]
                     [--batch-size BATCH_SIZE] [--num-epochs NUM_EPOCHS]
                     [--device DEVICE] [--test]
                     [--learning-rate LEARNING_RATE]

optional arguments:
  -h, --help            show this help message and exit
  --model-id MODEL_ID   id of the experiment
  --num-workers NUM_WORKERS
                        number of workers to use
  --batch-size BATCH_SIZE
                        batch size for training
  --num-epochs NUM_EPOCHS
                        batch size for training
  --device DEVICE       device to train model on
  --test                (flag) test the model on the test set
  --learning-rate LEARNING_RATE
                        learning rate for the optimizer
```

