import threading

from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView

from rest_framework.parsers import FileUploadParser
from wsgiref.util import FileWrapper

from .serializers import FileSerializer

import uuid

# load our libs
import sys
import os
sys.path.append("../../")
from argparse import Namespace

from video_classifier import VideoClassifier

our_args = Namespace(model="ours",
                    device="cpu",
                    batch_size=16,
                    num_workers=1,
                    model_id="test", # TODO CHANGE
                    learning_rate = 1e-3,
                    test=True)

pretrained_args = Namespace(model="pretrained",
                    device="cpu",
                    batch_size=16,
                    num_workers=1,
                    model_id="test", # TODO CHANGE
                    learning_rate = 1e-3,
                    test=True)

# create temp dir
temp_dir = "temp"
if not os.path.exists(temp_dir):
    os.mkdir(temp_dir)

our_clf = VideoClassifier(our_args)
pretrained_clf = VideoClassifier(pretrained_args)

def index(request):
    return HttpResponse("Hello, fake world.")

active_threads = {}

thread_results = {}

def add_job(job_id, clf, src, dest, skip_frames):
    def run():
        global thread_results
        thread_results[job_id] = clf.run(src, dest, skip_frames)

    thread = threading.Thread(target=run)

    active_threads[job_id] = thread

    thread.setDaemon(True)
    thread.start()

    return

def is_done(job_id):
    return active_threads[job_id].is_alive()


@api_view(['GET'])
def upload_link(request):
    '''
    Add giftcard amount to a fund
    '''
    filepath = request.query_params['link']

    model = request.query_params['model']
    skip_frames = int(request.query_params['skip_frames'])

    # download video and get new filepath
    if filepath.startswith('http'):
        # TODO: download video and save it to a location
        pass
        # set filepath to downloaded video

    video_id = str(uuid.uuid4())
    ext = ".mp4"
    dest_video_path = os.path.join(temp_dir, video_id + ext)
    clf = {
        "ours": our_clf,
        "pretrained": pretrained_clf,
    }[model]

    # start a background thread for the job
    add_job(video_id, clf, filepath, dest_video_path, skip_frames)

    return Response({
            'message': "ok",
            'job_id': video_id,
            'result_vid_path': dest_video_path
        }, status=status.HTTP_200_OK)


@api_view(["GET"])
def results(request):
    job_id = request.query_params["job_id"]

    print("----")
    print(active_threads)


    if job_id not in active_threads:
        return Response({
            "done": False,
            "message": "look again, broer"
        }, status=status.HTTP_404_NOT_FOUND)

    if job_id in thread_results:
        return Response({
            "done": True,
            "results": thread_results[job_id]
        }, status=status.HTTP_200_OK)
    else:
        return Response({
            "done": False
        }, status=status.HTTP_200_OK)


@api_view(['GET'])
def get_video(request):

    filepath = request.query_params['path']

    print(filepath)

    file = FileWrapper(open(filepath, 'rb'))
    response = HttpResponse(file, content_type='video/mp4')
    response['Content-Disposition'] = 'attachment; filename=my_video.mp4'

    return response

@api_view(['POST'])
def upload_file(request):

    # TODO
    if request.method == 'POST':
        pass

    return Response({'message': 'All is well'}, status=status.HTTP_200_OK)


class FileUploadView(APIView):

    # FIXME: Doesn't work yet
    parser_classes = (FileUploadParser,)

    def post(self, request, *args, **kwargs):
        file_serializer = FileSerializer(data=request.data)

        if file_serializer.is_valid():
            file_serializer.save()
            return Response(file_serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
