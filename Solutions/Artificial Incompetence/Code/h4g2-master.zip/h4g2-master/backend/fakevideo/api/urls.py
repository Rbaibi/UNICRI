from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    # path('upload/(?P<filename>[^/]+)$', views.FileUploadView.as_view()),
    path('upload', views.upload_file),
    path('upload_link', views.upload_link),
    path('results', views.results),
    path('showvideo', views.get_video),
]
