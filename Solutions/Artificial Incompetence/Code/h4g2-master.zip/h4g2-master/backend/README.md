### Start server

```
cd fakevideo

python manage.py migrate
python manage.py runserver
```

(Admin) URL: 127.0.0.1:8000

### FakeAPI

[PUT]  /api/upload\_link

- *query_params*: link
- *example*: 127.0.0.1:8000/api/upload_link?link=https://www.youtube.com/watch?v=fa3XzXYP-yI
- *response*:
```
{
    'link': <link>
}
```
