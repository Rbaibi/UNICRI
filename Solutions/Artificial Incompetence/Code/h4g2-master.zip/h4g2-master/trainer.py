import os
import math
import time
import logging
from collections import defaultdict

import torch
import numpy as np
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import DataLoader
from torchvision.utils import save_image
import pretrainedmodels


import commont_util as utils
from datasets import get_image_dataset

log = logging.getLogger(__name__)

class AkashClassifier(nn.Module):
    
    def __init__(self):
        super().__init__()
        # self.layers = nn.Sequential(
        #     nn.Linear(3*128*128, 10),
        #     nn.ReLU(True),
        #     nn.Linear(10, 2)
        # )

        # load a pre-trained xception model
        self.model = pretrainedmodels.xception()

        num_ftrs = self.model.last_linear.in_features
        self.model.last_linear = nn.Sequential(
            nn.Dropout(p=0.3),
            nn.Linear(num_ftrs, 2)
        )

        for i, param in self.model.named_parameters():
            param.requires_grad = False
        
        for param in self.model.last_linear.parameters():
            param.requires_grad = True

    def forward(self, x):
        return self.model(x)

class Trainer(object):
    # TODO: Akash
    IMAGE_SIZE = (128, 128)

    MODEL_WTS_DIR = "model"

    def __init__(self, args):

        self.device = torch.device(args.device)
        self.batch_size = args.batch_size
        self.num_workers = args.num_workers
        self.model_id = args.model_id
        self.learning_rate = args.learning_rate
        self.mode = "test" if args.test else "train"

        # load data
        self.dataset_sizes = {}
        self.datasets = {}
        self.dataloaders = {}
        self._load_data(args)

        log.info("Device: {}".format(self.device))

        self._mkdirs()

        # load model
        self.model = None
        self._create_model(args)
        self.model.to(self.device)

    def _get_save_path(self):
        if os.path.exists("./results") and os.path.isdir("./results"):
            res_path = "./results"
        else:
            # to get it to work in django.
            # i'm so sorry
            # forgive me sensei
            res_path = "../../results"
        return os.path.join(res_path, self.model_id)

    def _mkdirs(self):
        if self.mode == "test":
            return
        utils.mkdir("results")
        save_path = self._get_save_path()
        utils.mkdir(save_path)
        utils.mkdir(os.path.join(save_path, self.MODEL_WTS_DIR))


    def _load_data(self, args):
        log.info("Loading data!")
        
        for split in {"train", "val", "test"}:
            self.datasets[split] = get_image_dataset(split, self.IMAGE_SIZE)
            self.dataset_sizes[split] = len(self.datasets[split])
            self.dataloaders[split] = DataLoader(self.datasets[split],
                                                 batch_size=self.batch_size, shuffle=True, num_workers=self.num_workers)

    def _create_model(self, args):
        # TODO: Akash
        self.model = AkashClassifier() 

    def load(self, map_location=None, last=False):
        # TODO: load the monitor as well
        if map_location is None:
            map_location = self.device

        file_name = "model_last.wts" if last else "model.wts"
        path = os.path.join(self._get_save_path(),
                            self.MODEL_WTS_DIR, file_name)

        log.info("Loading model from {} (loc: {})".format(path, map_location))
        self.model.load_state_dict(torch.load(path, map_location=map_location))

    def run_epoch(self, epoch, phase, device, optimizer):
        log.info("Phase: {}".format(phase))

        if phase == 'train':
            self.model.train()
        else:
            self.model.eval()

        running_loss = 0.0
        running_n = 0.0
        running_correct = 0.0

        n_batches = (self.dataset_sizes[phase] // self.batch_size) + 1

        # keep track of metrics, so we can compute the average later on
        epoch_metrics = defaultdict(float)


        criterion = nn.CrossEntropyLoss().to(self.device)

        
        # Iterate over data.
        for batch_idx, (x, y) in enumerate(self.dataloaders[phase], 1):
            x = x.to(device)
            y = y.to(device)

            if phase == "train":
                optimizer.zero_grad()

            # forward
            # track history if only in train
            with torch.set_grad_enabled(phase == 'train'):
                pred = self.model(x)

                loss = criterion(pred, y)

                # backward + optimize only if in training phase
                if phase == 'train':
                    loss.backward()
                    optimizer.step()
                
                correct = (torch.softmax(pred, dim=1).detach().argmax(1) == y).sum()

    
            # statistics
            running_loss += float(loss) * x.size(0)
            running_n += x.size(0)
            running_correct += correct.item()
            if batch_idx % 10 == 0:
                log.info("\t[{}/{}] Batch {}/{}: Loss: {:.4f}, Accuracy: {:.4f}".format(phase,
                                                                      epoch,
                                                                      batch_idx,
                                                                      n_batches,
                                                                      running_loss / running_n,
                                                                      running_correct / running_n))

        epoch_loss = running_loss / running_n
        epoch_accuracy = running_correct / running_n
        log.info("[{}] Epoch Loss: {}, Epoch Accuracy: {}".format(phase, epoch_loss, epoch_accuracy))

        return epoch_loss

    def train(self, num_epochs):

        root_path = self._get_save_path()

        model_path = os.path.join(root_path, "best_model.pkl")

        device = torch.device(self.device)

        self.model = self.model.to(device)

        optimizer = optim.Adam(
            self.model.parameters(), lr=self.learning_rate)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, patience=20)

        since = time.time()

        best_val_loss = float("inf")

        for epoch in range(1, num_epochs + 1):
            log.info('Epoch {}/{}'.format(epoch, num_epochs))

            train_loss = self.run_epoch(epoch,"train", device, optimizer)

            if math.isnan(train_loss):
                raise ValueError("NaN loss encountered")

            val_loss = self.run_epoch(
                epoch, "val", device, optimizer)

            if math.isnan(val_loss):
                raise ValueError("NaN loss encountered")

            if val_loss < best_val_loss:
                log.info("Lower loss of {} achieved (previous: {}). Saving model".format(
                    val_loss, best_val_loss))

                best_val_loss = val_loss
                # save the best model
                save_path = os.path.join(
                    self._get_save_path(), self.MODEL_WTS_DIR, "model.wts")

                torch.save(self.model.state_dict(), save_path)

            scheduler.step(val_loss)

        # save last epoch
        save_path = os.path.join(
            self._get_save_path(), self.MODEL_WTS_DIR, "model_last.wts")
        torch.save(self.model.state_dict(), save_path)

        time_elapsed = time.time() - since
        log.info('Training complete in {:.0f}m {:.0f}s'.format(
            time_elapsed // 60, time_elapsed % 60))

    def test(self):
        device = torch.device(self.device)
        self.model = self.model.to(device)
        self.run_epoch(0, "test", device, None)
