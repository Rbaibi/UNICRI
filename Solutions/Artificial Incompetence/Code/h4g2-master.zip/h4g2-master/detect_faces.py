import os
import logging
import argparse

import numpy as np
from PIL import Image
import face_recognition

from datasets import get_video_dataset
from main import configure_logging
import commont_util as cutil


if __name__ == '__main__':
    
    configure_logging("detect_faces", True)

    log = logging.getLogger("detect_faces")
    
    parser = argparse.ArgumentParser("detect_faces", description="detects faces form a list of videos")

    parser.add_argument("--input", type=str)
    parser.add_argument("--output", type=str)
    parser.add_argument("--skip-frames", dest="skip_frames", type=int, default=5)
    parser.add_argument("--batch-size", dest="batch_size", type=int, default=128)
    args = parser.parse_args()

    dataset = args.input
    dest_dir = args.output
    batch_size = args.batch_size
    skip_frames = args.skip_frames


    cutil.mkdir(dest_dir)

    v_dataset = get_video_dataset(dataset, batch_size)
    n_files = len(v_dataset)

    count = 0
    for i, (video_id, frame_it) in enumerate(v_dataset, 1):
        log.info("({}/{}):: Video: {}. Count: {}".format(i, n_files, video_id, count))

        _, video_name = os.path.split(video_id)
        video_name = video_name.split(".")[0]
        overall_frame_idx = 0
        for frame_numbers, batch, timestamps in frame_it:
            for frame_no, img in zip(frame_numbers, batch):
                overall_frame_idx += 1
                if overall_frame_idx % skip_frames != 0:
                    continue
                img = np.asarray(img)
                locations = face_recognition.face_locations(img)
                for idx, (top, right, bottom, left) in enumerate(locations):
                    face_image = img[top:bottom, left:right]
                    pil_image = Image.fromarray(face_image)

                    path = os.path.join(dest_dir, f"{video_name}_{frame_no}_{idx}.jpg")
                    pil_image.save(path)
                    count += 1



    