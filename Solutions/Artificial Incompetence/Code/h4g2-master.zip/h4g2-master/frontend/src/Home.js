import React, { PureComponent } from "react";
import Header from "./Header";
import SearchInput from "./SearchInput";

export default class App extends PureComponent {

  render() {
    return (
        <div className="MainPage">
            <SearchInput />
        </div>
    );
  }
}
