import React, { PureComponent } from "react";
import Header from "./Header";
import SearchInput from "./SearchInput";

import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import Loading from "./Loading";
import Results from "./Results";
import Home from "./Home";


export default class App extends PureComponent {

  render() {
    return (
    <Router>
        <div>
            <Header />

            <Route exact path="/" component={Home}/>
            <Route exact path="/loading" component={Loading} />
            <Route exact path="/results" component={Results} />
        </div>
    </Router>
    );
  }
}
