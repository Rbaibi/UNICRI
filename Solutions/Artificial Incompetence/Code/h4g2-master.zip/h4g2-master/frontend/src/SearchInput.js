import React from 'react';
import clsx from 'clsx';

import { makeStyles } from '@material-ui/core/styles';

import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

import InputBase from '@material-ui/core/InputBase';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import SearchIcon from '@material-ui/icons/Search';
import DirectionsIcon from '@material-ui/icons/Directions';

import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';

import Box from '@material-ui/core/Box';

import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import { Player } from 'video-react';

import ReactPlayer from 'react-player'

import axios from 'axios'


const useStyles = makeStyles(theme => ({
    root: {
        paddingTop: 200
    },
    second: {
      padding: '2px 4px',
      display: 'flex',
      alignItems: 'center',
      width: 400,
    },
    input: {
      marginLeft: 8,
      flex: 1,
    },
    iconButton: {
      padding: 10,
    },

    textField: {
        width: 100
    },
    container:{
        paddingTop: 50,
        paddingLeft: 200
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
    formControl: {
        paddingLeft: 200
    },
    group: {
        margin: theme.spacing(1, 0),
    },
}));


export function handleClick() {
    const link = localStorage.getItem('linkLocalStorage')
    if (link === "") { return }

    const putRequestPath = "http://127.0.0.1:8000/api/upload_link?link=" + link + "&model=ours&skip_frames=10"

    axios.get(putRequestPath)
        .then(res => {
            console.log(res.data)
            console.log(res.data['job_id'])

            localStorage.setItem('job_id', res.data['job_id'].toString())
            localStorage.setItem('result_vid_path', res.data['result_vid_path'])
        })
        .catch(res => {
            console.log("Some error")
        })
}

export default function OutlinedTextFields() {
  const classes = useStyles();
  const [values, setValues] = React.useState({
    link: '',
    model: 'ours',
    skip_frames: 10
  });

  const handleChange = name => event => {
    setValues({ ...values, [name]: event.target.value });
    localStorage.setItem('linkLocalStorage', event.target.value);
  };


  const handleRadiochange = model => event => {
      console.log(event.target.value)
      setValues({...values, [model]: event.target.value});
  };


  return (
        <div className={classes.root}>
            <Grid container spacing={3}>
                <Grid item xs={4}>
                <FormControl component="fieldset" className={classes.formControl}>
                    <FormLabel component="legend">Model</FormLabel>
                    <RadioGroup
                      aria-label="Model"
                      name="model"
                      value={values.model}
                      onChange={handleRadiochange}
                      className={classes.group}
                    >
                      <FormControlLabel value="pretrained" control={<Radio />} label="Pretrained" />
                      <FormControlLabel value="ours" control={<Radio />} label="Ours" />
                    </RadioGroup>
                  </FormControl>

                    <form className={classes.container} noValidate autoComplete="off">
                        <TextField
                          id="standard-name"
                          label="Skip frames"
                          value={values.skip_frames}
                          className={classes.textField}
                          margin="small"
                        />
                    </form>


                </Grid>
                <Grid item xs={4}>

                        <Paper className={classes.second}>
                            <InputBase
                                className={classes.input}
                                placeholder="Enter Link"
                                value={values.name}
                                onChange={handleChange('link')}
                                inputProps={{ 'aria-label': 'Search Google Maps' }}
                            />
                            <Link to="/loading">
                                <IconButton className={classes.iconButton} aria-label="Search" onClick={handleClick}>
                                    <SearchIcon />
                                </IconButton>
                            </Link>
                        </Paper>
                </Grid>

                <Grid item xs={4}>



                </Grid>
            </Grid>

        </div>
  );
}
