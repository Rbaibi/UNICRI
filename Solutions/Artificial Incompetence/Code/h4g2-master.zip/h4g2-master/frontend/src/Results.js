import React, { PureComponent } from "react";

import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';

import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import { Player } from 'video-react';

import ReactPlayer from 'react-player'

import { Line } from 'react-chartjs-2';


const data = {
  labels: [],
  datasets: [
    {
      label: 'Real',
      fill: false,
      lineTension: 0.1,
      backgroundColor: 'rgba(62, 119, 4,0.4)',
      borderColor: 'rgba(121, 198, 43, 1)',
      borderCapStyle: 'butt',
      borderDash: [],
      borderDashOffset: 0.0,
      borderJoinStyle: 'miter',
      pointBorderColor: 'rgba(121, 198, 43, 1)',
      pointBackgroundColor: 'black',
      pointBorderWidth: 1,
      pointHoverRadius: 5,
      pointHoverBackgroundColor: 'rgba(121, 198, 43, 1)',
      pointHoverBorderColor: 'rgba(220,220,220,1)',
      pointHoverBorderWidth: 2,
      pointRadius: 2,
      pointHitRadius: 10,
      data: []
  }, {
      label: "Fake",
      fill: false,
      lineTension: 0.1,
      backgroundColor: "rgba(142, 8, 8, 0.4)",
      borderColor: "rgb(255, 45, 45)",
      borderCapStyle: 'butt',
      borderDash: [],
      borderDashOffset: 0.0,
      borderJoinStyle: 'miter',
      pointBorderColor: "rgb(255, 45, 45)",
      pointBackgroundColor: "black",
      pointBorderWidth: 1,
      pointHoverRadius: 5,
      pointHoverBackgroundColor: 'rgb(255, 45, 45)',
      pointHoverBorderColor: "yellow",
      pointHoverBorderWidth: 2,
      pointRadius: 2,
      pointHitRadius: 10,
      data: [],
      spanGaps: false,
    }
  ]
};



export default class ResultsComponent extends PureComponent {

    render() {

        const labels = JSON.parse("[" + localStorage.getItem('labels') + "]")
        const real   = JSON.parse("[" + localStorage.getItem('real') + "]")
        const fake   = JSON.parse("[" + localStorage.getItem('fake') + "]")

        data['labels']              = labels
        data['datasets'][0]['data'] = real
        data['datasets'][1]['data'] = fake

        console.log(data)

        const videourl = "http://localhost:8000/api/showvideo?path=" + localStorage.getItem('result_vid_path')

        return (
            <div style={{paddingTop: 100, paddingLeft: 50, paddingRight: 100}}>
                <Grid container spacing={2}>

                    <Grid item xs={1}></Grid>

                    <Grid item xs={5}>
                        <ReactPlayer url={videourl} playing controls style={{height: 300}}/>
                    </Grid>
                    <Grid item xs={5}>
                        <Line data={data} />
                    </Grid>
                    <Grid item xs={1}></Grid>
                </Grid>

                <Grid container spacing={3} style={{paddingTop: 50}}>
                    <Grid item xs={1}></Grid>

                    <Grid item xs={5}>

                        <Button variant="contained" color="secondary">
                          Flag Video
                        </Button>
                        <Button variant="contained" style={{margin: 5}}>
                          Details
                        </Button>
                    </Grid>
                    <Grid item xs={6}></Grid>
                </Grid>


            </div>
        );
    }



}
