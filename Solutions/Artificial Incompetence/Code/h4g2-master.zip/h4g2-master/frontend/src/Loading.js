import React, { PureComponent } from "react";
import Header from "./Header";

import axios from 'axios'


export default class LoadingComponent extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            resultsAvailable: false
        };

        this.apiRequest()
    }

    apiRequest() {

        const getResults = "http://127.0.0.1:8000/api/results?job_id=" + localStorage.getItem('job_id')

        axios.get(getResults)
            .then(res => {
                console.log(res)

                if (res.data['done']) {
                    this.setState({resultsAvailable: true})
                    if (res.data['results'] === undefined) {
                        return
                    }

                    // process results

                    let labels = []
                    let real   = []
                    let fake   = []

                    console.log(res.data['results']);

                    for (let i in res.data['results']) {

                        let obj = res.data['results'][i]

                        labels = labels.concat(obj['timestamp'])
                        real   = real.concat(obj['real'])
                        fake   = fake.concat(obj['fake'])
                    }

                    localStorage.setItem('labels', labels.toString())
                    localStorage.setItem('real', real.toString())
                    localStorage.setItem('fake', fake.toString())

                    console.log(localStorage);

                }

            })
            .catch(res => {
                console.log("Some error")
            })
    }

    componentDidMount() {
        setInterval(() => {

            if (this.state.resultsAvailable === false) {
                this.apiRequest()
            } else {
                this.props.history.push('/results')
            }
        }, 3000)
    }

    render() {

        const resultsAvailable = this.state.resultsAvailable;
        let view;


        return (
            <div className="Loading">

                <img src={ require('./loading_3.gif') } style={{height: 350, paddingTop:150, paddingLeft:700}}/>

            </div>
        );
    }



}
