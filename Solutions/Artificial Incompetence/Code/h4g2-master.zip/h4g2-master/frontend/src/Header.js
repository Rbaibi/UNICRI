import React, { PureComponent } from "react";
import "./Header.css";

import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';

import { BrowserRouter as Router, Route, Link } from "react-router-dom";


export default class Header extends PureComponent {


    buttonClick() {
        this.props.history.push("/")
    }


    render() {
        return (
            <AppBar position="static">
                <Toolbar variant="dense">
                <IconButton edge="start" color="inherit" aria-label="Menu">
                    <MenuIcon />
                </IconButton>
                    <Button color="inherit"> Home</Button>

                    <Button color="inherit"> About </Button>
                    <Button color="inherit"> Team </Button>
                </Toolbar>
            </AppBar>
        );
    }
}
