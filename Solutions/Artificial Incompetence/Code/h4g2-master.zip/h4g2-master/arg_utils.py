import argparse


def parse_args():
    """Parse args
    """
    parser = argparse.ArgumentParser(description="TODO")
    parser.add_argument("--verbose", dest="verbose", default=False,
                        action="store_true", help="set to true for verbose output")
    parser.add_argument("--seed", type=int, dest="seed", required=False,
                        default=42, help="random seed")

    subparsers = parser.add_subparsers(dest="module", help="module to run")

    train_parser = subparsers.add_parser("train", help="train a model")

    add_train_args(train_parser)

    clf_parser = subparsers.add_parser("clf", help="run on video")
    clf_parser.add_argument("--model", required=True, choices={"pretrained", "ours"}, help="which model to use")
    clf_parser.add_argument("--input", required=True, type=str, help="location of input video")
    clf_parser.add_argument("--output", required=True, type=str, help="location of output video (will be overwritten)")
    clf_parser.add_argument("--skip-frames", 
                    dest="skip_frames", required=False, type=int, default=5, 
                    help="number of frames to skip")
    clf_parser.add_argument("--make-plots", 
                            default=False,
                            action="store_true",
                            help="store plots - true / false")
    add_train_args(clf_parser)

    run_clf_parser = subparsers.add_parser("run-clf", help="run on video")
    run_clf_parser.add_argument("--model", required=True, choices={"pretrained", "ours"}, help="which model to use")
    run_clf_parser.add_argument("--input", required=True, type=str, help="location of input folder")
    run_clf_parser.add_argument("--output", required=True, type=str, help="location of output folder")
    run_clf_parser.add_argument("--skip-frames", 
                    dest="skip_frames", required=False, type=int, default=5, 
                    help="number of frames to skip")
    add_train_args(run_clf_parser)



    test_clf_parser = subparsers.add_parser("test-clf", help="run on video")
    test_clf_parser.add_argument("--model", required=True, choices={"pretrained", "ours"}, help="which model to use")
    test_clf_parser.add_argument("--id", required=True, type=str, help="video id")
    test_clf_parser.add_argument("--skip-frames", 
                    dest="skip_frames", required=False, type=int, default=5, 
                    help="number of frames to skip")
    add_train_args(test_clf_parser)

    


    return parser.parse_args()


def add_train_args(parser):
    parser.add_argument("--model-id", dest="model_id",
                        type=str, required=True, help="id of the experiment")
    parser.add_argument("--num-workers", type=int, dest="num_workers", default=1,
                        help="number of workers to use")
    parser.add_argument("--batch-size", dest="batch_size",
                        type=int, default=16, help="batch size for training")
    parser.add_argument("--num-epochs", dest="num_epochs", type=int, default=1,
                        help="batch size for training")
    parser.add_argument("--device", type=str, default="cpu",
                        help="device to train model on")
    parser.add_argument("--test", action="store_true",
                        default=False, help="(flag) test the model on the test set")
    # Learning rates
    parser.add_argument("--learning-rate", type=float, dest="learning_rate",
                        help="learning rate for the optimizer", default=1e-3)