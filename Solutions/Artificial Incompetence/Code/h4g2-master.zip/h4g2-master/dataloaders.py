import os
import logging
import collections

import torch
import imageio
from PIL import Image
from torch.utils.data import Dataset


import commont_util as cutil

log = logging.getLogger(__name__)


class FrameIterator(object):
    # TODO: this might be leaky
    # TODO: use a context manager here?

    def __init__(self, path, batch_size=32):
        self.batch_size = batch_size
        self.path = path
        self.vid = imageio.get_reader(self.path)
        meta_data = self.vid.get_meta_data()
        self.num_frames = meta_data["nframes"]
        log.debug("{}: {} frames".format(self.path, self.num_frames))

    def n_batches(self):
        return int(self.num_frames // self.batch_size) + 1

    def __iter__(self):
        batch = []
        timestamps = []
        frame_numbers = []

        fr_num = 0
        while True:
            try:
                im = self.vid.get_next_data()
                timestamp = float(fr_num) / self.vid.get_meta_data()['fps']

                batch.append(Image.fromarray(im))
                frame_numbers.append(fr_num)
                timestamps.append(timestamp)

                if len(batch) % self.batch_size == 0:
                    yield frame_numbers, batch, timestamps
                    batch = []
                    timestamps = []
                    frame_numbers = []

            except IndexError:
                log.warning("Skipping frame {}".format(fr_num))
                break

            fr_num += 1

        if len(batch) > 0:
            yield frame_numbers, batch, timestamps


class VideoLoader(object):

    def __init__(self, videos_dir, batch_size, extensions=[".mp4"], video_ids=None):
        self.videos_dir = videos_dir
        self.batch_size = batch_size
        self.video_ids = video_ids

        log.info("Scanning directory: {}".format(self.videos_dir))
        self.videos = []
        for file_path in cutil.list_dir(self.videos_dir):
            if not cutil.check_extension(file_path, extensions):
                continue

            file_name = os.path.split(file_path)[1].split(".")[0]
            if self.video_ids and file_name not in self.video_ids:
                log.debug("Skipping video: {}".format(file_path))
                continue

            self.videos.append(file_path)
            log.debug("Found video file: {}".format(file_path))

        log.info("Found {} videos".format(len(self.videos)))

    def __iter__(self):
        for video_name in self.videos:
            yield video_name, FrameIterator(video_name,
                                            batch_size=self.batch_size)


    def __len__(self):
        return len(self.videos)

