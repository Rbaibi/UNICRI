import os
import time
import logging
from collections import defaultdict

import torch
import imageio
import numpy as np
import matplotlib.pyplot as plt

import face_recognition
from PIL import Image, ImageDraw, ImageFont
from dataloaders import FrameIterator
from datasets import get_transforms, get_transforms_xception

from trainer import Trainer

log = logging.getLogger(__name__)

class VideoClassifier:
    def __init__(self, args):
        self.trainer = Trainer(args)
        self.trainer.load()

        self.model_type = args.model

    def run(self, video_path, dest_video_path, skip_frames, make_plots=False):
        start_time = time.time()
        log.info(f"Input: {video_path}, Output:{dest_video_path}, Skip Frames: {skip_frames}")
        reader = imageio.get_reader(video_path)
        fps = reader.get_meta_data()['fps']
        writer = imageio.get_writer(dest_video_path, fps=fps)

                
        class_to_idx = self.trainer.datasets["train"].class_to_idx
        idx_to_class = {int(idx):cl for (cl,idx) in class_to_idx.items()}


        if self.model_type == "pretrained":
            log.info("Overwriting our model with the FaceForensics pretrained model")
            self.trainer.model = torch.load("./ffmodels/face_detection/xception/all_raw.p", map_location="cpu")

            idx_to_class = {
                0: "real",
                1: "fake"
            }

            # == 1.3
            scale_factor = 0.3

        elif self.model_type == "ours":
            scale_factor = 0.0

        transforms = get_transforms_xception("test", None)

        self.trainer.model.eval()

        class_colors = {
            "real": (0, 255, 0),
            "fake": (255, 0, 0)
        }

        all_probs = []
        prev_preds = None
        for frame_idx, frame in enumerate(reader):
            frame = Image.fromarray(frame)
            draw = ImageDraw.Draw(frame)
            timestamp = float(frame_idx) / reader.get_meta_data()['fps']
        
            # we will use previous frames detection's results (assumption: skip_frames is low) 
            if skip_frames > 0 and frame_idx % skip_frames != 0:
                if prev_preds:
                    for idx, (top, right, bottom, left) in enumerate(locations):
                        top = max(int(top - ((scale_factor/2) * top)), 0)
                        left = max(int(left - ((scale_factor/2) * left)), 0)
                        
                        bottom = min(int(bottom + ((scale_factor/2) * bottom)), frame.height)
                        right = min(int(right + ((scale_factor/2) * right)), frame.width)

                        pred_prob, pred_class = prev_preds[idx]
                        
                        draw.rectangle(((left, top), (right, bottom)), outline=class_colors[pred_class], width=3)
                        draw.text((left, top), f"{pred_class}: {100*pred_prob}%")

                writer.append_data(np.asarray(frame))
                continue

            img = np.asarray(frame)
            locations = face_recognition.face_locations(img)

            probs = defaultdict(list)

            prev_locations = locations
            prev_preds = []
            for idx, (top, right, bottom, left) in enumerate(locations):
                top = max(int(top - ((scale_factor/2) * top)), 0)
                left = max(int(left - ((scale_factor/2) * left)), 0)
                
                bottom = min(int(bottom + ((scale_factor/2) * bottom)), frame.height)
                right = min(int(right + ((scale_factor/2) * right)), frame.width)

                to_clf = transforms(Image.fromarray(img[top:bottom, left:right])).unsqueeze(0)

                with torch.no_grad():
                    pred_prob = torch.softmax(self.trainer.model(to_clf), dim=1)

                for idx, cl in idx_to_class.items():
                    probs[cl].append(float(pred_prob[0][idx]))

                pred = pred_prob.argmax(1)

                pred_class = idx_to_class[int(pred[0])]
                
                pred_prob = round(float(pred_prob.max()), 2)

                prev_preds.append((pred_prob, pred_class))

                draw.rectangle(((left, top), (right, bottom)), outline=class_colors[pred_class], width=3)
                draw.text((left, top), f"{pred_class}: {100*pred_prob}%")

            agg_probs = {}
            for cl, p in probs.items():
                agg_probs[cl] = np.mean(p)

            agg_probs["timestamp"] = timestamp
            all_probs.append(agg_probs)

            writer.append_data(np.asarray(frame))
        
        writer.close()
    
        if make_plots:
            name = os.path.split(dest_video_path)[1]
            name = name.split(".")[0]

            fig = plt.figure(figsize=(20, 10))
            ax = fig.add_subplot(111)

            timestamps = [a["timestamp"] for a in all_probs] 
            real_prob = [a["real"] for a in all_probs] 
            fake_prob = [a["fake"] for a in all_probs] 
            
            ax.plot(timestamps, real_prob, color="b", marker="o", label="Prob. Real")
            ax.plot(timestamps, fake_prob, color="r", marker="x", label="Prob. Fake")
            ax.legend()
            ax.set_xlabel("Time")
            ax.set_ylabel("Probability")
            
            fig.savefig(name + ".png", dpi=300)

        log.info(f"Created {dest_video_path}, Time Taken: {time.time() - start_time} seconds")
        return all_probs
