import os
import logging
import subprocess
import pickle as pkl

log = logging.getLogger(__name__)


def mkdir(path):
    if not os.path.exists(path):
        os.mkdir(path)

def delete_files(folder):
    for file_ in list_dir(folder):
        os.remove(file_)

def list_dir(path, sorted=True):
    files = []
    for file_name in os.listdir(path):
        files.append(os.path.join(path, file_name))
    files.sort()
    return files


def save_obj(path, obj):
    with open(path, "wb") as writer:
        pkl.dump(obj, writer)


def load_obj(path):
    with open(path, "rb") as reader:
        return pkl.load(reader)


def run_command(cmd, supress_output=True):
    """Runs a given command

    Arguments:
        cmd {list} -- list of strings, where each item is separated by a space

    Keyword Arguments:
        supress_output {bool} -- whether to supress stdout (default: {True})
    """
    cmd = [str(c) for c in cmd]
    with open(os.devnull, 'w') as dev_null:
        log.info("Command: {}".format(" ".join(cmd)))
        subprocess.run(cmd, check=True,
                       stdout=dev_null if supress_output else None,
                       stderr=dev_null if supress_output else None)


def check_extension(path, extensions):
    """Checks if a file is a certain type

    Arguments:
        path {str} -- path of the file or filename
        extensions {list} -- a list of extensions to check against

    """
    return any(path.endswith(ext) for ext in extensions)
