
from torchvision.datasets import ImageFolder
from dataloaders import FrameIterator, VideoLoader
from torchvision.transforms import Resize, CenterCrop, ToTensor, Compose
from torchvision import transforms

def get_video_dataset(name, batch_size):
    path = {
        "df": "UNICRI Challenge Dataset/Deepfakes/",
        "f2f": "UNICRI Challenge Dataset/Face2Face/",
        "fs": "UNICRI Challenge Dataset/FaceSwap/",
        "o": "UNICRI Challenge Dataset/Original/",
    }[name]
    return VideoLoader(path, batch_size=batch_size)

def get_transforms(split, image_size):
    return Compose([Resize(image_size), ToTensor()])

def get_transforms_xception(split, image_size):
    xception_default_data_transforms = {
        'train': transforms.Compose([
            transforms.Resize((299, 299)),
            transforms.ToTensor(),
            transforms.Normalize([0.5]*3, [0.5]*3)
        ]),
        'val': transforms.Compose([
            transforms.Resize((299, 299)),
            transforms.ToTensor(),
            transforms.Normalize([0.5] * 3, [0.5] * 3)
        ]),
        'test': transforms.Compose([
            transforms.Resize((299, 299)),
            transforms.ToTensor(),
            transforms.Normalize([0.5] * 3, [0.5] * 3)
        ]),
    }[split]

    return xception_default_data_transforms

def get_image_dataset(split, image_size):
    try:
        path = f"./datasets/small_dataset_splits/{split}"
        return ImageFolder(path, transform=get_transforms_xception(split, image_size)) 
    except FileNotFoundError:
        # really dirty trick to get it to work. i'm so sorry
        path = f"../../datasets/small_dataset_splits/{split}"
        return ImageFolder(path, transform=get_transforms_xception(split, image_size)) 

