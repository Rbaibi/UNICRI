var oldurl = "";
//chrome.extension.sendMessage({}, function(response) {

	var readyStateCheckInterval = setInterval(function() {
	var url = window.location.toString();
	if (document.readyState === "complete" && oldurl != url) {
		//clearInterval(readyStateCheckInterval);
		oldurl = url;

		$( ".infobox" ).remove();

		var video_id = window.location.search.split('v=')[1];
		var ampersandPosition = video_id.indexOf('&');
		if(ampersandPosition != -1) {
		video_id = video_id.substring(0, ampersandPosition);
		};
		

		
		var html = '<div class="infoboxgreen infobox"><i class=" green fas fa-2x fa-check"></i></div>';
		if(video_id == "C8pKdI44Z68")
		{	
			console.log("Red");
			html = '<div class="infoboxred infobox"><i class=" red fas fa-2x fa-exclamation-triangle">  <span>This video has been confirmed a deepfake! Click <a href="http://localhost:8080/report">here</a> to see the report.</span> </i> </div>';
		}
		if(video_id == "yDk-MTkzlcc")
		{
			html = '<div class="infoboxorange infobox"><i class=" yellow fas fa-2x fa-exclamation-triangle"></i> <span>This video <bold>might</bold> be a deepfake!</span> 	</div>';
			console.log("Yellow");
		}

		// $('#primary-inner').prepend(html);
		$('[class="style-scope ytd-video-primary-info-renderer"][id="container"]').prepend(html);
		
		console.log(video_id);

	}
	}, 100);
//});

