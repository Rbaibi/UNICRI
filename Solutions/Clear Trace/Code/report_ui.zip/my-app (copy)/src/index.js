import React from "react";
import { render } from "react-dom";
import store from "./js/store/index";
import App from "./js/components/App.jsx";
import { BrowserRouter } from "react-router-dom";
import './js/6b64e492cd.js'; 


window.store = store;

render(
  <BrowserRouter>
      <App />
  </BrowserRouter>,

  document.getElementById("root")
);
