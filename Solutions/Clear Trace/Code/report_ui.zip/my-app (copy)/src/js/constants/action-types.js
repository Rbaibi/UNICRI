// src/js/constants/action-types.js

export const ADD_ARTICLE = "ADD_ARTICLE";
