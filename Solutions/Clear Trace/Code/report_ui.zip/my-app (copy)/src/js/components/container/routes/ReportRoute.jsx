import React, { Component } from "react";
import ReactDOM from "react-dom";
import FeatureResult from "../../presentational/FeatureResult.jsx";
import MenuBar from "../../presentational/MenuBar.jsx";
import Report from "../../presentational/Report.jsx";

import {
    Flex
  } from 'rebass'

class ReportRoute extends Component {
  constructor() {
    super();
  }


  render() {
    return (
    <Flex flexWrap={"wrap"} justifyContent={"space-evenly"} >    
        <MenuBar/>
        <Report/>
    </Flex>
    );
  }
}

export default ReportRoute;