import React from "react";
import PropTypes from "prop-types";
import FeatureResult from "./FeatureResult.jsx";

import {
    Box,
    Heading,
    Text,
    Flex,
    Input,
    Image,
    Card
  } from 'rebass'

import styled, {css} from 'styled-components';

const MenuBarDiv = styled.div`
width: 100%;
height: 40px;
background: black;
padding: 10px 0;
line-height: 40px;
margin: 0;
`

const PropertyLeft = styled(Text)`
  float: left;
`;

const PropertyRight = styled(Text)`
  float: right;
`;

const ClearDiv = styled.div`
  clear: both
`;

const Property = ({property, value}) => (
    <div>
        <PropertyLeft  color='rgb(46, 68, 78)' fontFamily='Arial'>
        {property}
        </PropertyLeft>

        <PropertyRight  color='rgb(46, 68, 78)' fontFamily='Arial'>
        {value}
        </PropertyRight>
        <ClearDiv />
    </div>
);

const ReportCard = ({width}) => (
    <Card width={width} backgroundColor={"white"}  my={10} 
    borderRadius={10}
    boxShadow='0 0 16px rgba(0, 0, 0, .25)'>

    </Card>
);

const UnderlinedBox = styled(Box)`
border-bottom: 2px solid cyan;
    border-bottom: 2px solid #f6f4f5;
`

const Image1 = styled(Image)`
    margin: 0 auto;
    display: block;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
`

const CardTitle = ({icon, title}) => (
    <UnderlinedBox width={1} >
        
        <Text lineHeight={1.5} textAlign={"center"} fontSize='1.4rem' color='rgb(46, 68, 78)' fontFamily='Arial' px={100} py={10}>
            <i className={"fas fa-lg " + {icon}}></i> {title}
        </Text>
    </UnderlinedBox>
);

const Bar = styled.div`
    background: #dd3e54; /* fallback for old browsers */
    background: -webkit-linear-gradient(to right, #6be585, #dd3e54); /* Chrome 10-25, Safari 5.1-6 */
    background: linear-gradient(to right, #6be585, #dd3e54); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
    width: 100%;
    height: 25px;
    border-radius: 3px;
    //border: 1px solid black;
  `

const IndicatorMarker = styled.div`
    width: 2px;
    height: 25px;
    position: relative;
    top: 0;
    left: ${props => props.p || "50%"};;
    background: black;
`

const IndicatorArrow = styled.div`
    position: relative;
    top:-10px;
    left: -9px;
    width: 0; 
    height: 0; 
    border-left: 10px solid transparent;
    border-right: 10px solid transparent;
    
    border-top: 10px solid black;

`

const IndicatorBox = styled.div`
    width: 20; 
    height: 0; 
    border-left: 20px solid transparent;
    border-right: 20px solid transparent;
    
    border-top: 20px solid #ff;
`

const Indicator = ({percent}) => (
    <IndicatorMarker p={percent}>
        <IndicatorArrow>
        </IndicatorArrow>
    </IndicatorMarker>
);


const Report = () => (
<Box width={0.9} backgroundColor={"white"} p={50} my={20} 
    borderRadius={10}
    boxShadow='0 0 16px rgba(0, 0, 0, .25)'>


    <Flex flexWrap={"wrap"} justifyContent={"space-evenly"} alignItems="center">

    <Box width={1}>
        <Heading  color='rgb(46, 68, 78)' fontFamily='Arial'>
        Generated report for: "Watch Deepfaked Mark Zuckerberg Rant About How He Controls You"
        </Heading>
    </Box>

    <Card width={1}  backgroundColor={"#FFCCCC"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
        <Box>
            <Text lineHeight={3} textAlign={"center"}  color='rgb(46, 68, 78)' fontFamily='Arial'>
            <i className="fas fa-lg fa-exclamation-triangle"></i> This video has been fact checked and is confirmed fake!
            </Text>
        </Box>
    </Card>

    <Card width={1} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
        <Flex flexWrap={"wrap"} justifyContent={"space-evenly"}>
            <CardTitle title={"Video Information"} icon={" fa-exclamation-triangle"}/>

            <Box width={0.3} my={20}>
                <Property property={"Video origin:"} value={<a href={"https://www.youtube.com/watch?v=C8pKdI44Z68"}>Youtube</a>}/>
                <Property property={"Video length:"} value={"1:55"}/>
                <Property property={"Views:"} value={"1,300,000"}/>
                <Property property={"Category:"} value={"Business"}/>

            </Box>


            {/* <Box width={0.3} my={20}>
                <Property property={"Video origin:"} value={<a href={"https://www.youtube.com/watch?v=C8pKdI44Z68"}>Youtube</a>}/>
                <Property property={"Video length:"} value={"1:55"}/>
                <Property property={"Views:"} value={"1,300,000"}/>
                <Property property={"Category:"} value={"Business"}/>
            </Box> */}

            <Box width={1} px={10} py={2}>
                <Bar>
                    <Indicator percent={"80%"}/>
                </Bar>
            </Box>


        </Flex>
    </Card>












    <Card width={1} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
        <Flex flexWrap={"wrap"} justifyContent={"space-evenly"} alignItems="center">

            <CardTitle title={"Static Frame Analysis"} icon={"fa-exclamation-triangle"}/>
            <Box width={0.01} height="auto">
                <i className="fas fa-lg fa-chevron-left"></i>
            </Box>

            <Card width={0.3} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0px 16px rgba(0, 0, 0, .25)'>
                <Box textAlign={"center"}>
                    <Image1 src="https://screenshotscdn.firefoxusercontent.com/images/0cf3fc09-0554-450e-a64b-2382e5e390de.png" width='100%' m={'auto'} my={10} />
                    <Text lineHeight={3} textAlign={"center"}  color='rgb(46, 68, 78)' fontFamily='Arial'>
                    Still frame at 0:22.
                    </Text>
                </Box>

                <FeatureResult feature={"Facial artifacts"} percentage={"85%"}/>
                <FeatureResult feature={"Eye artifacts"} percentage={"63%"}/>
                <FeatureResult feature={"Lip artifacts"} percentage={"45%"}/>
                <FeatureResult feature={"Cheek artifacts"} percentage={"10%"}/> 
            </Card>
            <Card width={0.3} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
                <Box textAlign={"center"}>
                    <Image1 src="https://screenshotscdn.firefoxusercontent.com/images/ff591303-2a29-4e3d-a519-dd4decf38c7f.png" width='100%' m={'auto'} my={10} />
                    <Text lineHeight={3} textAlign={"center"}  color='rgb(46, 68, 78)' fontFamily='Arial'>
                    Still Frame from 0:54.
                    </Text>
                </Box>

                <FeatureResult feature={"Facial artifacts"} percentage={"85%"}/>
                <FeatureResult feature={"Eye artifacts"} percentage={"63%"}/>
                <FeatureResult feature={"Lip artifacts"} percentage={"45%"}/>
                <FeatureResult feature={"Cheek artifacts"} percentage={"10%"}/> 
            </Card>

            <Card width={0.3} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
                <Box textAlign={"center"}>
                    <Image1 src="https://screenshotscdn.firefoxusercontent.com/images/9de359f0-0dad-421b-aff3-7ec712588db3.png" width='100%' m={'auto'} my={10} />
                    <Text lineHeight={3} textAlign={"center"}  color='rgb(46, 68, 78)' fontFamily='Arial'>
                    Still Frame from 1:33.
                    </Text>
                </Box>

                <FeatureResult feature={"Facial artifacts"} percentage={"85%"}/>
                <FeatureResult feature={"Eye artifacts"} percentage={"63%"}/>
                <FeatureResult feature={"Lip artifacts"} percentage={"45%"}/>
                <FeatureResult feature={"Cheek artifacts"} percentage={"10%"}/> 
            </Card>

            <Box width={0.01} height="auto">
                <i className="fas fa-lg fa-chevron-right"></i>
            </Box>
        </Flex>

        {/* <Box width={1} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
            <Flex flexWrap={"wrap"} justifyContent={"space-evenly"}>
            <CardTitle title={"Static Frame Analysis"} icon={"fa-exclamation-triangle"}/>


            </Flex>
        </Box> */}

    </Card>











    <Card width={1} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
        <Flex flexWrap={"wrap"} justifyContent={"space-evenly"} alignItems="center">

            <CardTitle title={"Video Analysis"} icon={"fa-exclamation-triangle"}/>
            <Box width={0.01} height="auto">
                <i className="fas fa-lg fa-chevron-left"></i>
            </Box>

            <Card width={0.3} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
                <Box textAlign={"center"}>
                    <Image1 src="https://i.imgur.com/v9L26iA.gif" width='100%' m={'auto'} my={10} />
                    <Text lineHeight={3} textAlign={"center"}  color='rgb(46, 68, 78)' fontFamily='Arial'>
                    Video Frame from 0:12.
                    </Text>
                </Box>

                <FeatureResult feature={"Facial motions"} percentage={"85%"}/>
                <FeatureResult feature={"Eye movement"} percentage={"63%"}/>
                <FeatureResult feature={"Lip movement"} percentage={"45%"}/>
                <FeatureResult feature={"Cheek Clipping"} percentage={"10%"}/> 
            </Card>
            <Card width={0.3} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
                <Box textAlign={"center"}>
                    <Image1 src="https://i.imgur.com/DRQB4fu.gif" width='100%' m={'auto'} my={10} />
                    <Text lineHeight={3} textAlign={"center"}  color='rgb(46, 68, 78)' fontFamily='Arial'>
                    Video Frame from 0:37.
                    </Text>
                </Box>

                <FeatureResult feature={"Lip movement"} percentage={"91%"}/>
                <FeatureResult feature={"Eye movement"} percentage={"52%"}/>
                <FeatureResult feature={"Cheek Clipping"} percentage={"38%"}/> 
                <FeatureResult feature={"Facial motions"} percentage={"27%"}/>
            </Card>
            <Card width={0.3} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
                <Box textAlign={"center"}>
                    <Image1 src="https://i.imgur.com/oSgfvVF.gif" width='100%' m={'auto'} my={10} />
                    <Text lineHeight={3} textAlign={"center"}  color='rgb(46, 68, 78)' fontFamily='Arial'>
                    Video Frame from 1:03.
                    </Text>
                </Box>

                <FeatureResult feature={"Lip movement"} percentage={"95%"}/>
                <FeatureResult feature={"Eye movement"} percentage={"42%"}/>
                <FeatureResult feature={"Facial motions"} percentage={"33%"}/>
                <FeatureResult feature={"Cheek Clipping"} percentage={"23%"}/> 
            </Card>

            <Box width={0.01} height="auto">
                <i className="fas fa-lg fa-chevron-right"></i>
            </Box>
        </Flex>

        {/* <Box width={1} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
            <Flex flexWrap={"wrap"} justifyContent={"space-evenly"}>
            <CardTitle title={"Static Frame Analysis"} icon={"fa-exclamation-triangle"}/>


            </Flex>
        </Box> */}

    </Card>

















{/* 
    <Card width={1} backgroundColor={"white"} my={10} borderRadius={10} boxShadow='0 0 16px rgba(0, 0, 0, .25)'>
        <Flex flexWrap={"wrap"} justifyContent={"space-evenly"}>
            <CardTitle title={"Video Information"} icon={" fa-exclamation-triangle"}/>

            <Box width={0.3} my={20}>
                <Property property={"Video origin:"} value={<a href={"https://www.youtube.com/watch?v=C8pKdI44Z68"}>Youtube</a>}/>
                <Property property={"Video length:"} value={"1:55"}/>
                <Property property={"Views:"} value={"1,300,000"}/>
                <Property property={"Category:"} value={"Business"}/>

            </Box>


            <Box width={0.3} my={20}>
                <Property property={"Video origin:"} value={<a href={"https://www.youtube.com/watch?v=C8pKdI44Z68"}>Youtube</a>}/>
                <Property property={"Video length:"} value={"1:55"}/>
                <Property property={"Views:"} value={"1,300,000"}/>
                <Property property={"Category:"} value={"Business"}/>
            </Box>

            <Box width={1} px={10} py={2}>
                <Bar>
                    <Indicator/>
                </Bar>
            </Box>


        </Flex>
    </Card> */}

    

    </Flex>
</Box>
);

export default Report;
