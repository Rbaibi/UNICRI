import React from "react";
import PropTypes from "prop-types";

import {
    Box,
    Heading,
    Text,
    Flex,
    Input,
    Image
  } from 'rebass'

import styled, {css} from 'styled-components';

const MenuBarDiv = styled.div`
width: 100%;
height: 40px;
background: black;
padding: 10px 0;
line-height: 40px;
margin: 0;
`

const SearchBar = styled.input`
  height: 29px;
  width: 100%;
  border-radius: 3px;
  background: #f2f2f2;
  border:0;
  padding: 0 15px;
`

const MenuBar = () => (
   <Box width={1} m={0}>
      <MenuBarDiv>
        <Flex justifyContent={"space-around"} >
          <Box width={0.2}>
            <Heading color={"#ffffff"}>CT</Heading>
          </Box>

          <Box width={0.05}>
            <Text fontSize={"1rem"} color={"#7f7f67"}>Rising</Text>
          </Box>

          <Box width={0.05}>
            <Text fontSize={"1rem"} color={"#7f7f67"}>Hits</Text>
          </Box>

          <Box width={0.4}>
            <SearchBar color={"#7f7f67"} placeholder={"Search for Reports"}/>
          </Box>

          <Box width={0.05}>
                    <Image
            width={40}
            height={40}
            src='https://source.unsplash.com/random/1280x720'
            borderRadius={20}
          />
          </Box>

        </Flex>
      </MenuBarDiv>
   </Box>
);


export default MenuBar;
