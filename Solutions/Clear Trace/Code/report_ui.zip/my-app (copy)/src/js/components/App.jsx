import { Route } from "react-router-dom";

import React from "react";
import List from "./List.jsx";
import ReportRoute from "./container/routes/ReportRoute.jsx";

const App = () => (
  <div>
    <Route exact path='/' component={List}/>
    <Route path='/report' component={ReportRoute}/>
    <Route path='/contact' component={List}/> 
  </div>
);

export default App;
