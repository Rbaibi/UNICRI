import React from "react";
import PropTypes from "prop-types";


import {
    Box,
    Heading,
    Text,
    Flex
  } from 'rebass'

import styled, {css} from 'styled-components';

const Bar = styled.div`
    background: #dd3e54; /* fallback for old browsers */
    background: -webkit-linear-gradient(to right, #6be585, #dd3e54); /* Chrome 10-25, Safari 5.1-6 */
    background: linear-gradient(to right, #6be585, #dd3e54); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
    width: 70px;
    height: 20px;
    border-radius: 3px;
    //border: 1px solid black;
    float: right;

    -moz-box-shadow:    2px 2px 2px 2px #ccc;
  -webkit-box-shadow: 2px 2px 2px 2px #ccc;
  box-shadow:         2px 2px 2px 2px #ccc;
  `

const Indicator = styled.div`
    width: 2px;
    height: 20px;
    position: relative;
    top: 0;
    left: ${props => props.p || "50%"};;
    background: black;
`
  
const FeatureResult = ({feature, percentage}) => (
    <Box px={2}>
        <Flex>
            <Box p={3} width={1/2}>
                <Text fontSize='1rem' color='rgb(46, 68, 78)' fontFamily='Arial'>
                    {feature}
                </Text>
            </Box>
            <Box p={3} width={1/2}>
            <Bar>
                <Indicator p={percentage}/>
            </Bar>
            </Box>
        </Flex>
        
       
    </Box>

);


export default FeatureResult;
