APPROACH
- load movies to google cloud storage
- extract frames using extract_frames.py and save frames on google cloud storage
- send pubsub messages to a cloud function (via send_to_pubsub.py) that contains the file extract_faces.py to extract all faces. This is done in parallell. The face images are saved on google cloud storage
- Use google cloud automl and feed it the balanced_train.csv to apply transfer learning on google their CNN (all clickthrough no coding)
- Evaluate model