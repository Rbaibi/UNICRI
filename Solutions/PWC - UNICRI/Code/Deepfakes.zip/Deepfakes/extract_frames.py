import cv2 
import os 

# get data dir
path_data =r"/home/jupyter/face2face"
# path_data =r"/home/jupyter/original"
# path_data =r"/home/jupyter/faceswap"
# path_data =r"/home/jupyter/deepfakes"

# get save dir
path_save =r"/home/jupyter/face2face_frames"
# path_save =r"/home/jupyter/original_frames"
# path_save =r"/home/jupyter/faceswap_frames"
# path_save =r"/home/jupyter/deepfakes_frames"

# get content of directory
files = os.listdir(path_data)

# Function to extract frames 
def FrameCapture(file): 
    
    # Path to video file 
    vidObj = cv2.VideoCapture(os.path.join(path_data,file)) 
  
    # Get framerate
    frame_rate = int(vidObj.get(cv2.CAP_PROP_FPS))

     # Create save folder
    path_frame = os.path.join(path_save,file.split('.')[0]) 
    os.makedirs(path_frame)
    
    # Used as counter variable 
    count = 0
  
    # checks whether frames were extracted 
    success = 1
  
    while success: 
  
        # vidObj object calls read 
        # function extract frames 
        success, image = vidObj.read() 
        # Saves the frames with frame-count 
        cv2.imwrite(os.path.join(path_frame,"fr_{}_{}.jpg".format(frame_rate,count)), img=image)

        count += 1

for ind,file in enumerate(files):
    if ind % 50 == 0:
        print(ind)
    FrameCapture(file)