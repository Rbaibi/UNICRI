from google.cloud import storage as gcs
import cv2
import os 
import time
import base64
import numpy as np
import argparse


def extract_face(event, context):
    """
    take a picture and run script to extract face
    """
    file_location = base64.b64decode(event['data']).decode('utf-8')
    gcs_client = gcs.Client()
    #get the bucket
    gcs_bucket = gcs_client.get_bucket('hackathon-deepfakes')
    
    def get_file(file_location):
        #saves the figure into the local folder
        frame_obj = gcs_bucket.get_blob(file_location)
        frame_obj.download_to_filename('/tmp/start_image.jpg')
        #get file for the face extraction model
        deploy_obj = gcs_bucket.get_blob('deploy.prototxt')
        deploy_obj.download_to_filename('/tmp/deploy.prototxt')
        #get caffee model
        caffee_obj = gcs_bucket.get_blob('res10_300x300_ssd_iter_140000.caffemodel')
        caffee_obj.download_to_filename('/tmp/res10_300x300_ssd_iter_140000.caffemodel')
        
    def get_face():
        # main function to extract the face
        read = 0
        saved = 0
        skip = 5
        var_confidence = 0.5
        net = cv2.dnn.readNetFromCaffe('/tmp/deploy.prototxt',
                                       '/tmp/res10_300x300_ssd_iter_140000.caffemodel')
        
        # grab the frame from the file
        frame = cv2.imread('/tmp/start_image.jpg')
        
        # grab the frame dimensions and construct a blob from the frame
        (h, w) = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 1.0,
                                     (300, 300), (104.0, 177.0, 123.0))

        # pass the blob through the network and obtain the detections and
        # predictions
        net.setInput(blob)
        detections = net.forward()

        # ensure at least one face was found
        if len(detections) > 0:
            # we're making the assumption that each image has only ONE
            # face, so find the bounding box with the largest probability
            i = np.argmax(detections[0, 0, :, 2])
            confidence = detections[0, 0, i, 2]

            # ensure that the detection with the largest probability also
            # means our minimum probability test (thus helping filter out
            # weak detections)
            if confidence > var_confidence:
                # compute the (x, y)-coordinates of the bounding box for
                # the face and extract the face ROI
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (startX, startY, endX, endY) = box.astype("int")
                face = frame[startY:endY, startX:endX]

                # write the frame to disk
                p = ('/tmp/new_image.jpg')
                cv2.imwrite(p, face)
                saved += 1

    
    def save_face(file_location):
        new_file_location = file_location.replace('frames', 'faces')
        blob = gcs_bucket.blob(new_file_location)
        blob.upload_from_filename('/tmp/new_image.jpg')
        os.remove('/tmp/start_image.jpg')
        
    
    get_file(file_location)
    get_face()
    time.sleep(10)
    save_face(file_location)
    print('Finished image: ' + file_location)